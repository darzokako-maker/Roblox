using System;
using System.Drawing;
using System.Windows.Forms;
using WeAreDevs_API;

namespace RobloxExecutor
{
    public partial class MainForm : Form
    {
        ExploitAPI api = new ExploitAPI();

        public MainForm()
        {
            InitializeComponent();
            SetupCustomUI();
        }

        private void SetupCustomUI()
        {
            this.Text = "Stealth Executor v1.0";
            this.Size = new Size(680, 420);
            this.BackColor = Color.FromArgb(20, 20, 20);
            this.ForeColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnInject_Click(object sender, EventArgs e)
        {
            lblStatus.Text = "Durum: Inject Ediliyor...";
            lblStatus.ForeColor = Color.Orange;
            try
            {
                api.LaunchExploit();
                lblStatus.Text = "Durum: Inject Komutu Gonderildi!";
                lblStatus.ForeColor = Color.LimeGreen;
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Durum: Hata Olustu!";
                lblStatus.ForeColor = Color.Red;
                MessageBox.Show("Baglanti hatasi: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLuaEditor.Text))
            {
                MessageBox.Show("Lütfen önce bir Lua kodu yazın!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            api.SendLuaScript(txtLuaEditor.Text);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLuaEditor.Clear();
        }
    }
}
